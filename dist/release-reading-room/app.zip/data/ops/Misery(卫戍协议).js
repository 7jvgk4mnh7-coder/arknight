window.TERRA_OP = {"n":"Misery(卫戍协议)","r":6,"c":"特种","b":"处决者","o":"","id":"None","info":null,"archives":[],"modules":[],"base":null,"alters":[],"siblings":[]};
