window.TERRA_OP = {"n":"预备干员-近战","r":3,"c":"先锋","b":"尖兵","o":"","id":"None","info":null,"archives":[],"modules":[],"base":null,"alters":[],"siblings":[]};
