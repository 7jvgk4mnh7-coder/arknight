window.TERRA_OP = {"n":"预备干员-医疗(卫戍协议)","r":4,"c":"医疗","b":"医师","o":"","id":"None","info":null,"archives":[],"modules":[],"base":null,"alters":[],"siblings":[]};
