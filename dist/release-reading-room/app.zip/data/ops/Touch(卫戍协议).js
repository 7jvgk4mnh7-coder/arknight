window.TERRA_OP = {"n":"Touch(卫戍协议)","r":6,"c":"医疗","b":"医师","o":"","id":"None","info":null,"archives":[],"modules":[],"base":null,"alters":[],"siblings":[]};
