window.TERRA_OP = {"n":"预备干员-术师","r":3,"c":"术师","b":"中坚术师","o":"","id":"None","info":null,"archives":[],"modules":[],"base":null,"alters":[],"siblings":[]};
