window.TERRA_OP = {"n":"盟约·辅助干员","r":4,"c":"辅助","b":"巫役","o":"","id":"None","info":null,"archives":[],"modules":[],"base":null,"alters":[],"siblings":[]};
