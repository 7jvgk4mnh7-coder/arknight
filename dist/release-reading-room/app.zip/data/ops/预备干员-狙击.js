window.TERRA_OP = {"n":"预备干员-狙击","r":3,"c":"狙击","b":"速射手","o":"","id":"None","info":null,"archives":[],"modules":[],"base":null,"alters":[],"siblings":[]};
