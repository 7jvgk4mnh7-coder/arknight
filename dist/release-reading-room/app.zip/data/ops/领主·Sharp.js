window.TERRA_OP = {"n":"领主·Sharp","r":6,"c":"近卫","b":"领主","o":"","id":"None","info":null,"archives":[],"modules":[],"base":null,"alters":[],"siblings":[]};
