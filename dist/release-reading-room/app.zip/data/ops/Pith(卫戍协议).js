window.TERRA_OP = {"n":"Pith(卫戍协议)","r":6,"c":"术师","b":"扩散术师","o":"","id":"None","info":null,"archives":[],"modules":[],"base":null,"alters":[],"siblings":[]};
