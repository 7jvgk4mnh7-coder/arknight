window.TERRA_OP = {"n":"Raidian(卫戍协议)","r":6,"c":"辅助","b":"凝滞师","o":"","id":"None","info":null,"archives":[],"modules":[],"base":null,"alters":[],"siblings":[]};
